'''
Usage:
    get_CNAG.py [--transcript=None] [--transcript_file=None] [--flanks]
    
Example with single transcript including 1kb upstream and downstream of TSS and PAS:
    get_CNAG.py --transcript="CNAG_01733T0" --flanks
    
Example with multiple transcripts in file with only sequence within transcript:
    get_CNAG.py --transcript_file="My_fav_CNAGs.txt"
    
    where My_fav_CNAGs.txt is a text file with a transcript ID on each new line:
        CNAG_01733T0
        CNAG_00081T0
        CNAG_04387T0
        
To run for all transcripts in the genome:
    get_CNAG.py --transcript="All"
'''

__author__ = 'jordanburke'
import re
import sys
from docopt import docopt

base_dir = sys.argv[0].split("get_CNAG")[0]
print base_dir

arguments=docopt(__doc__,version="get_CNAG 0.1")
print arguments

transcript = arguments["--transcript"]
transcript_file = arguments["--transcript_file"]

flanks = False
if arguments["--flanks"]:
    flanks = True


transcript_list = []
if transcript == "All":
    transcript_list = None
elif transcript is not None:
    transcript_list.append(transcript)

if transcript_file is not None:
    with open(transcript_file, "r") as fin:
        for line in fin:
            transcript_list.append(line.strip())
            
print transcript_list
print flanks

def fix_fasta_file(fasta_file):
    #Read fasta file for chromosome into list
        
    fasta_dict = {}
    with open(fasta_file, "r") as fin:
        for line in fin:
            if line.startswith(">"):
                chr_num = int(line[4:6].strip())
                print chr_num
                fasta_dict[chr_num] = []
            else:
                fasta_dict[chr_num].append(line.strip())
    
    for chromosome, seq_list in fasta_dict.iteritems():
        fasta_dict[chromosome] = "".join(seq_list)
  
    with open("{0}_fixed.fa".format(fasta_file.split(".")[0]), "w") as fout:
        for chromosome, seq_list in fasta_dict.iteritems():
            fout.write(">chr"+str(chromosome)+" of Cryptococcus neoformans var. grubii H99 (CNA3)\n")
            fout.write(seq_list+"\n")
            
def load_fasta(fixed_fasta_file):
    fasta_dict = {}
    
    with open(fixed_fasta_file, "r") as fasta:
        for line in fasta:
            if line.startswith(">"):
                chr_num = int(line[4:6].strip())
            else:
                fasta_dict[chr_num]=line.strip()
    return fasta_dict
    
def load_gff3(gff3_file):
    transcript_dict = {}
    with open(gff3_file, "r") as gff3:
        for line in gff3:
            columns = re.split(r'\t+', line)
            if len(columns) > 1:
                if columns[2] == "mRNA":
                    CNAG = columns[8]
                    CNAG = CNAG[3:15]
                
                    #Transcript dictionary: keys are CNAG, values are [start, end, strand, chromosome number]
                    transcript_dict[CNAG] = [int(columns[3]), int(columns[4]), columns[6], int(columns[0][3:5].strip())]
    return transcript_dict
                
def complement(seq):
    complement = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A','N':'N'} 
    bases = list(seq) 
    bases = [complement[base] for base in bases] 
    return ''.join(bases)

def reverse_complement(s):
        return complement(s[::-1])
    
def get_transcript_sequence(fixed_fasta_file, gff3_file, transcript_list=None, flanks=False):
    fasta_dict = load_fasta(fixed_fasta_file)
    transcript_dict = load_gff3(gff3_file)
    
    seq_dict = {}
    
    if transcript_list is not None:
        for transcript in transcript_list:
            if len(transcript) != 12:
                print "Transcript name must be given in this format: CNAG_00001T0"
                sys.exit()
                
            start = transcript_dict[transcript][0]-1
            end = transcript_dict[transcript][1]
            strand = transcript_dict[transcript][2]
            chromosome = transcript_dict[transcript][3]
            if flanks == True:
                start = start-1500
                end = end+1500
            
            seq_dict[transcript] = fasta_dict[chromosome][start:end]
            
            if strand == "-":
                seq_dict[transcript] = reverse_complement(seq_dict[transcript])
            
            with open("{0}.fa".format(transcript), "w") as fout:
                fout.write(seq_dict[transcript])
                
    
    else:
        for transcript, coords in transcript_dict.iteritems():
            start = transcript_dict[transcript][0]
            end = transcript_dict[transcript][1]
            strand = transcript_dict[transcript][2]
            chromosome = transcript_dict[transcript][3]
            
            if flanks == True:
                start = start-1500
                end = end+1500
            
            seq_dict[transcript] = fasta_dict[chromosome][start:end]
            
            if strand == "-":
                seq_dict[transcript] = reverse_complement(seq_dict[transcript])
            
            with open("{0}.fa".format(transcript), "w") as fout:
                fout.write(seq_dict[transcript])
                
get_transcript_sequence(base_dir+"CNA3-gobs_fixed.fa", base_dir+"CNA3_FINAL_CALLGENES_1_gobs.gff3", transcript_list, flanks)       
    